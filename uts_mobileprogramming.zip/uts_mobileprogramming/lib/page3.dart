import 'package:flutter/material.dart';

class Page3 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        leading: GestureDetector(
          onTap: () {Navigator.pop(context);},
          child: Icon(
            Icons.arrow_back,
            color: Colors.black,
          ),
        ),
        actions: <Widget>[
          Padding(
              padding: EdgeInsets.only(right: 20.0),
              child: GestureDetector(
                onTap: () {},
                child: Icon(
                  Icons.search),
              )),
          Padding(
              padding: EdgeInsets.only(right: 20.0),
              child: GestureDetector(
                onTap: () {},
                child: Icon(Icons.share),
              )),
        ],
        actionsIconTheme:
            IconThemeData(size: 30.0, color: Colors.black, opacity: 10.0),
      ),
      body: Stack(
        alignment: Alignment.center,
      children: <Widget>[
      ListView(
      children: [

        Container(
          padding: EdgeInsets.only(top: 15),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: <Widget>[
              Container(
              width: 320,
              child: Text('Baskin Robbins, Central Park Lower Ground',
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold))),

              Container(
                height: 60,
                width: 60,
                decoration: BoxDecoration(
                border: Border.all(width: 1.0, color: Colors.grey[400]),
                borderRadius: BorderRadius.all(
                Radius.circular(10))),
                child: Container(
                padding: EdgeInsets.all(5),
                child: Image.asset('images/baskin.png', height: 50, width: 50))
              )
            ],
          )
        ),

      
       Container(
         padding: EdgeInsets.only(top: 10),
         child: Row(
            children: <Widget>[
              Container(
                margin: EdgeInsets.only(left: 10),
                decoration: BoxDecoration(
                    color: Colors.orange[900],
                    borderRadius: BorderRadius.all(Radius.circular(50))),
                child: Row(children: [
                  Container(
                      padding: EdgeInsets.only(left: 10),
                      child: Icon(Icons.thumb_up_rounded, color: Colors.white, size: 18)),
                  Container(
                      padding: EdgeInsets.only(
                          top: 7, bottom: 7, left: 5, right: 10),
                      child: Text('Super Partner',
                          style: TextStyle(color: Colors.white, fontSize: 14))),
                ]),
              ),
              Container(
                padding: EdgeInsets.only(left: 10),
                child: Text(
                  'Sweets',
                  style: TextStyle(color: Colors.grey[600], fontSize: 14),
                ),
              )
            ],
          )
       ),

       Container(
         color: Colors.grey[200],
         margin: EdgeInsets.only(top: 20),
         padding: EdgeInsets.only(top: 20, bottom: 20),
         child: Row(
           mainAxisAlignment: MainAxisAlignment.spaceEvenly,
           children: [
             Column(
             children: <Widget>[

              Container(
              child: Row(
              children: [
              Container(
              margin: EdgeInsets.only(right: 5),
              child:Container(
              child: Icon(Icons.star_rounded, color: Colors.orange[800],
              ))),

              Container(
              child:Text('4.1',
              style: TextStyle(color: Colors.black, 
              fontSize: 16, fontWeight: FontWeight.bold))),
            ],)),
          
            SizedBox(
            height: 5,
            ),
          
            Container(
            child:Text('60+ ratings',
            style: TextStyle(color: Colors.grey[600], 
            fontSize: 14),
            ))]),

             Column(
             children: <Widget>[

              Container(
              child: Row(
              children: [
              Container(
              margin: EdgeInsets.only(right: 5),
              child:Container(
              child: Icon(Icons.location_on, color: Colors.red[700],
              ))),

              Container(
              child:Text('0.83 km',
              style: TextStyle(color: Colors.black, 
              fontSize: 16, fontWeight: FontWeight.bold))),
            ],)),
          
            SizedBox(
            height: 5,
            ),
          
            Container(
            child:Text('21 min',
            style: TextStyle(color: Colors.grey[600], 
            fontSize: 14),
            ))]),


             Column(
             children: <Widget>[

              Container(
              child: Row(
              children: [
              Text(r'$$$',
              style: TextStyle(color: Colors.black, 
              fontSize: 16, fontWeight: FontWeight.bold)),
              Text(r'$',
              style: TextStyle(color: Colors.grey, 
              fontSize: 16, fontWeight: FontWeight.bold))
              ],)),
          
              SizedBox(
              height: 7),
          
              Container(
              child:Text('over 100k',
              style: TextStyle(color: Colors.grey[600], 
              fontSize: 14),))]),

             Column(
             children: <Widget>[

              Container(
              child: Row(
              children: [
              Container(
              margin: EdgeInsets.only(right: 5),
              child:Container(
              child: Icon(Icons.thumb_up_rounded, color: Colors.red[700], size: 18,
              ))),

              Container(
              child:Text('Great taste',
              style: TextStyle(color: Colors.black, 
              fontSize: 16, fontWeight: FontWeight.bold))),
            ],)),
          
            SizedBox(
            height: 5,
            ),
          
            Container(
            child:Text('7 ratings',
            style: TextStyle(color: Colors.grey[600], 
            fontSize: 14),
            ))]),
           ],
         )
       ),

      Container(
          padding: EdgeInsets.only(top: 15),
          child: Row(
            children: <Widget>[
              Container(
                padding: EdgeInsets.only(left: 10),
                child: Image.asset('images/pickup.jpg', height: 50, width: 50)),
              
              Container(
                padding: EdgeInsets.only(left:10),
              child:Column(
                children: [
                  Container(
                  width: 250,
                  child: Text('Pickup: collect order at resto',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold))),

                  Container(
                  width: 250,
                  child: Text("Food'll be ready in 8 min",
                  style: TextStyle(fontSize: 14))),
                ],
              )),

              Container(
                child: Icon(Icons.info, size: 30, color: Colors.grey[800]))
            ],
          )
        ),

      Container(
        padding: EdgeInsets.only(top: 30, left: 10),
        child: Text('Available promos', 
        style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold))
      ),
      
      Container(
      decoration: BoxDecoration(
      border: Border(bottom: BorderSide(width: 7, color: Colors.grey[200]))),
      padding: EdgeInsets.only(top: 15, bottom: 15),
      child: Column(
        children: [
      Container(
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
            Row(
            children: <Widget>[
              Container(
                padding: EdgeInsets.only(left: 10),
                child: Image.asset('images/gopaylogo.png', height: 20, width: 20)),
              
              Container(
                padding: EdgeInsets.only(left: 10),
                child: Text('60k food discount. Min. order 200k with GoPay.',
                style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold))),
            ]),
            
            Container(
              margin: EdgeInsets.only(right: 10),
                child: Icon(Icons.arrow_forward_ios, size: 20))
           ])),

      Container(
          padding: EdgeInsets.only(top: 15),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
            Row(
            children: <Widget>[
              Container(
                padding: EdgeInsets.only(left: 10),
                child: Image.asset('images/promo3.png', height: 20, width: 20)),
              
              Container(
                padding: EdgeInsets.only(left: 10),
                child: Text('7k delivery discount. No min. order',
                style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold))),
            ]),
            
            Container(
              margin: EdgeInsets.only(right: 10),
                child: Icon(Icons.arrow_forward_ios, size: 20))
           ]))
          ])),

      Container(
        decoration: BoxDecoration(
        border: Border(bottom: BorderSide(width: 1, color: Colors.grey[200]))),
        padding: EdgeInsets.only(top: 20, bottom: 20, left: 10),
        child: Text('Buy 1 Get 1 Free #DiRumahAja', 
        style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold))
      ),

      Container(
        padding: EdgeInsets.only(left: 10, top: 20, bottom: 20, right: 10),
        child: Column(
          children: [
            Menu(
              title: 'Buy 1 get 1 free Single Scoop - Jajan Seru',
              text: 'Buy 1 get 1 free. Maksimal 1 rasa',
              hargab: '65.000',
              hargaa: '130.000',
              images: 'images/br1.jpg',
            ),

            Menu(
              title: 'Buy 1 get 1 free Value Scoop - Jajan Seru',
              text: 'Buy 1 get 1 free.ukuran per 1 cup 4oz . Maksimal 1 rasa',
              hargab: '85.000',
              hargaa: '170.000',
              images: 'images/br2.jpg',
            )
          ],)
      )

      ],),

      Positioned(
              bottom: 20,
            child: Container(
              height: 40,
              width: 100,
              margin: EdgeInsets.only(left: 10, right: 10),
              decoration: BoxDecoration(
                  color: Colors.red[700],
                  borderRadius: BorderRadius.all(
                      Radius.circular(50)),
              boxShadow: [
                  BoxShadow(
                  color: Colors.grey.withOpacity(0.5),
                  spreadRadius: 5,
                  blurRadius: 7,
                  offset: Offset(0, 3),),],),
            child: Container(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Icon(Icons.fastfood, color: Colors.white),

                  Text('Menu', style: TextStyle(fontSize: 16, color: Colors.white))
                  ]) 
            )
        ))
    ])
    );
  }
}

class Menu extends StatelessWidget {
  const Menu ({Key key, this.images, this.title, this.text, this.hargab, this.hargaa})
      : super(key: key);
  final String images;
  final String title;
  final String text;
  final String hargab;
  final String hargaa;
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.only(bottom: 20),
      decoration: BoxDecoration(
      border: Border(bottom: BorderSide(width: 1, color: Colors.grey[300]))),
      child: Column(
        children: [

        Row(
        children: <Widget>[

          Column(
          children: <Widget>[
          Container(
            width: 250,
            margin: EdgeInsets.only(top: 10),
            child:Container(
            child: Text(
              title,
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold))
          )),
          SizedBox(
            height: 6,
          ),

          Container(
          width: 250,
          child:Text(
            text,
            style: TextStyle(color: Colors.black, 
            fontSize: 15)
          )),
        ],),
      
        Container(
          margin: EdgeInsets.only(left:50),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(20),
            child: Image.asset(images, height: 80, width: 80, fit: BoxFit.cover))
        )
        ]),

          Container(
          padding: EdgeInsets.only(top:5),
          child: Row(
          children:<Widget>[
          Container(
          child:Text(
            hargab,
            style: TextStyle(color: Colors.black, 
            fontSize: 16, fontWeight: FontWeight.bold)
          )),

          Container(
          margin: EdgeInsets.only(left: 10),
          child:Text(
            hargaa,
            style: TextStyle(color: Colors.grey[600], 
            fontSize: 16, decoration: TextDecoration.lineThrough)
          )),

          Container(
                margin: EdgeInsets.only(left: 10),
                decoration: BoxDecoration(
                    color: Colors.red[700],
                    borderRadius: BorderRadius.all(Radius.circular(50))),
                child:Container(
                    padding: EdgeInsets.only(
                    top: 5, bottom: 5, left: 7, right: 7),
                    child: Text('Promo',
                    style: TextStyle(color: Colors.white, fontSize: 14))),
                ),
            ])),

        Container(
          margin: EdgeInsets.only(top:10),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Icon(Icons.favorite, color: Colors.grey[600]),
              
              Container(
                margin: EdgeInsets.only(right: 10),
                decoration: BoxDecoration(
                border: Border.all(width: 2, color: Colors.green[700]),
                borderRadius: BorderRadius.all(
                Radius.circular(50))),
                child: Container(
                padding: EdgeInsets.only(top:5, bottom: 5, left: 25, right: 25),
                child:Text('Add', 
                style: TextStyle(color: Colors.green[700], fontWeight: FontWeight.bold, fontSize: 16))),
              )
          ]))
        ]
      )
    );
  }
}