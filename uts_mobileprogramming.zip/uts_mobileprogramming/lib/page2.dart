import 'package:flutter/material.dart';
import 'package:uts_mobileprogramming/page3.dart';

class Page2 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        toolbarHeight: 95,
        backgroundColor: Colors.white,
        actionsIconTheme: IconThemeData(
         size: 30.0,
          color: Colors.black,
          opacity: 10.0
        ),

          leading: GestureDetector(
          onTap: (){Navigator.pop(context);},
          child: Icon(
            Icons.close,
            color: Colors.black,
          ),
        ),titleSpacing: 0,

        title: Container(
        child: Column(
        children: <Widget> [
        Container(
        child:Row(
        children: <Widget> [
        Text("Your Location", 
        style: TextStyle(color: Colors.grey, fontSize: 14)),
        Icon(Icons.arrow_drop_down, color: Colors.red)
        ])),
        
        Container(
        child:Row(
        children:<Widget> [
        Text('Tarumanagara University Campu...',
        style: TextStyle(color: Colors.black, fontSize: 16, fontWeight: FontWeight.bold))
        ])),

        ])
        ),

        bottom: PreferredSize(
          preferredSize: Size(1000, 1000),
          child: Container(
          color: Colors.white,
          child: Row(
                  children: <Widget>[
                    Container(
                      height: 40,
                      width: 411,
                      decoration: BoxDecoration(
                      color: Colors.grey[200],
                      borderRadius: BorderRadius.all(
                        Radius.circular(50))),

                    child: Row(
                      children: <Widget> [
                        InkWell(
                        onTap: () {},
                        child: Container(
                              padding: EdgeInsets.only(left: 10),
                              child:Icon(Icons.search, color: Colors.grey))),
                        Container(
                              padding: EdgeInsets.only(left: 10), 
                              child: Text('What would you like to eat?', 
                              style: TextStyle(color: Colors.grey[600], fontSize: 14))),
                        ]
                      )
                    ),
                  ],
                )
          )
        ),

        actions: <Widget>[
          Padding(
            padding: EdgeInsets.only(right:20),
            child: GestureDetector(
              onTap: (){},
              child: Icon(
                Icons.favorite
              ),
            ),
          ),
        ]
      ),

      body:ListView(
      children: <Widget>[

        Container(
        padding: EdgeInsets.only(top: 30),
        child : Image.asset('images/burgerking.jpg', height: 200)
        ),
        
        Container(
          padding: EdgeInsets.only(top: 20),
        child: Container(
          padding: EdgeInsets.only(left: 5),
          child: Row(
            children: <Widget>[
          Dot(),
          Container(
            padding: EdgeInsets.only(right:7),
          child: Icon(Icons.brightness_1_rounded, color: Colors.green, size: 15)),
          Dot(), Dot(), Dot(), Dot(), Dot(), Dot(), Dot(), Dot(), Dot(), Dot(),
        ],))),

        Container(
          padding: EdgeInsets.only(top: 30),
          child: Row (
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: <Widget> [
             Menu1(
               images: 'images/newthisweek.jpg',
               title: 'New this Week'),
             Menu1(
               images: 'images/nearme.jpg',
               title: 'Near me'),
             Menu1(
               images: 'images/pickup.jpg',
               title: 'Pickup')
            ],
          )
        ),

        Container(
          padding: EdgeInsets.only(top: 20),
          child: Row (
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: <Widget> [
             Menu1(
               images: 'images/pastiadapromo.jpg',
               title: 'Pasti ada promo'),
             Menu1(
               images: 'images/bestseller.jpg',
               title: 'Best Seller'),
             Menu1(
               images: 'images/readytocook.jpg',
               title: 'Ready to Cook')
            ],
          )
        ), 

        Container(
        padding: EdgeInsets.only(top: 30, left: 5),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: <Widget>[
            Container(
            child: Text( 'Choose from cuisines',
            style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold))),
            
            Container(
            margin: EdgeInsets.only(right:5),
            decoration: BoxDecoration(
            color: Colors.green[100],
             borderRadius: BorderRadius.all(
             Radius.circular(50))),
              child: Container(
                padding: EdgeInsets.only(top:10, bottom: 10, left: 15, right: 15),
                 child:Text('See all', 
                  style: TextStyle(color: Colors.green[800], fontWeight: FontWeight.bold))))
          ])),

        Container(
          padding: EdgeInsets.only(top: 10),
          child: Row (
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: <Widget> [
             Menu2(
               images: 'images/cu1.jpg',
               title: 'Beverages'),
             Menu2(
               images: 'images/cu2.jpg',
               title: 'Snacks'),
             Menu2(
               images: 'images/cu3.jpg',
               title: 'Sweets'),
             Menu2(
               images: 'images/cu4.jpg',
               title: 'Rice')
            ],
          )
        ), 

       Container(
        padding: EdgeInsets.only(top: 30, left: 5),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: <Widget>[
            Container(
            child: Text( 'Discount up to 60k',
            style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold))),
            
            Container(
            margin: EdgeInsets.only(right: 5),
            decoration: BoxDecoration(
            color: Colors.green[100],
             borderRadius: BorderRadius.all(
             Radius.circular(50))),
              child: Container(
                padding: EdgeInsets.only(top:10, bottom: 10, left: 15, right: 15),
                 child:Text('See all', 
                  style: TextStyle(color: Colors.green[800], fontWeight: FontWeight.bold))))
          ])),

         Container(
            margin: EdgeInsets.only(left: 5, top: 5),
            child: Text( 'Order anything with our promo.',
            style: TextStyle(fontSize: 16)),
          ),

         Container(
          child: Row (
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: <Widget> [
              InkWell(
                    onTap: (){
                      Navigator.push(context, 
                      MaterialPageRoute(builder: (context) => Page3()),
                    );},
             child: Menu3(
               images: 'images/ibaskin.jpg')),
               
             Menu3(
               images: 'images/iduck.jpg'),
            ],
          )
        ), 

         Container(
            margin: EdgeInsets.only(left: 5),
            child: Text( 'Top-rated by other foodies',
            style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
          ),
        
        Container(
            margin: EdgeInsets.only(left: 5, top: 5),
            child: Text('Sponsored',
            style: TextStyle(fontSize: 16)),
          ),

        Container(
          child: Row (
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: <Widget> [
             Menu3(
               images: 'images/iburger.jpg'),
             Menu3(
               images: 'images/ifamily.jpg'),
            ],
          )
        ),
        ]),

      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        items: <BottomNavigationBarItem> [

          BottomNavigationBarItem(
            backgroundColor: Colors.blue,
            icon: Image.asset('images/compas.png', width: 24),
            title: Text('Explore', style: TextStyle(color: Colors.black)) 
          ),

          BottomNavigationBarItem(
            icon: Image.asset('images/pickup1.png', width: 24),
            title: Text('Pickup', style: TextStyle(color: Colors.grey[800]))
          ),

          BottomNavigationBarItem(
            icon: Icon(Icons.search, color: Colors.grey[700]),
            title: Text('Search', style: TextStyle(color: Colors.grey[800]))
          ),

          BottomNavigationBarItem(
            icon: Image.asset('images/promo2.png', width: 24),
            title: Text('Promos', style: TextStyle(color: Colors.grey[800]))
          ),

          BottomNavigationBarItem(
            icon: Image.asset('images/history.png', width: 24),
            title: Text('History', style: TextStyle(color: Colors.grey[800]))
          )
        ]
      ),
    );
  }
}

class Menu1 extends StatelessWidget {
  const Menu1 ({Key key, this.images, this.title, this.textcolor})
      : super(key: key);
  final String images;
  final String title;
  final Color textcolor;
  @override
  Widget build(BuildContext context) {
    return Container(
      child: Column(
        children: <Widget>[
          Container(
            margin: EdgeInsets.only(top: 10),
            child:Container(
              child: Image.asset(
            images, height: 100, width:100,
          ))),
          SizedBox(
            height: 7,
          ),
          Container(
          child:Text(
            title,
            style: TextStyle(color: textcolor ?? Colors.black, 
            fontSize: 16, fontWeight: FontWeight.bold),
          ))
        ],
      ),
    );
  }
}

class Dot extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.only(right: 5),
      child: Column(
        children: <Widget>[
          Container(
            child:Icon(
            Icons.brightness_1_rounded, color: Colors.grey, size: 15
          )),
        ],
      ),
    );
  }
}

class Menu2 extends StatelessWidget {
  const Menu2 ({Key key, this.images, this.title, this.textcolor})
      : super(key: key);
  final String images;
  final String title;
  final Color textcolor;
  @override
  Widget build(BuildContext context) {
    return Container(
      child: Column(
        children: <Widget>[
          Container(
            margin: EdgeInsets.only(top: 10),
            child:Container(
              child: Image.asset(
            images, height: 80, width:80,
          ))),
          SizedBox(
            height: 7,
          ),
          Container(
          child:Text(
            title,
            style: TextStyle(color: textcolor ?? Colors.black, 
            fontSize: 16, fontWeight: FontWeight.bold),
          ))
        ],
      ),
    );
  }
}

class Menu3 extends StatelessWidget {
  const Menu3 ({Key key, this.images, this.title, this.textcolor})
      : super(key: key);
  final String images;
  final String title;
  final Color textcolor;
  @override
  Widget build(BuildContext context) {
    return Container(
      child: Column(
        children: <Widget>[
          Container(
            child:Container(
              child: Image.asset(
            images, height: 300, width:200,
          ))),
        ],
      ),
    );
  }
}