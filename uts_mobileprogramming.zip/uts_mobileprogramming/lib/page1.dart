import 'package:flutter/material.dart';
import 'package:uts_mobileprogramming/page2.dart';

class Page1 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: DefaultTabController(
        length: 3,
        child: Scaffold(

          appBar: AppBar(
            toolbarHeight: 80,
            backgroundColor: Colors.orange[800],
            bottom: PreferredSize(
              preferredSize: Size(1000, 1000),
              
              child: Container(
                color: Colors.orange[800],
                padding: EdgeInsets.only(bottom: 20),
                child: TabBar(  
                indicator: BoxDecoration(
                borderRadius: BorderRadius.circular(50),
                color: Color(0x50FFD180),
              ),
              
              tabs: [
                Container(height: 35, width: 95, 
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: <Widget> [
                    Container(child : Image.asset('images/promo.png', height: 25, width: 25)),
                    Container(child: Text('PROMO'))])),

                Container(height: 35, width: 95,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: <Widget> [
                    Container(child : Image.asset('images/home-non.png', height: 25, width: 25)),
                    Container(child: Text('HOME'))])),

                Container(height: 35, width: 95,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: <Widget> [
                    Container(child : Image.asset('images/chat-non.png', height: 25, width: 25)),
                    Container(child: Text('CHAT'))])),
                ],
              ),
            )
          )
        ),

          body: TabBarView(
            
            children: [
                
                Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                Text('Coming Soon', 
                style: TextStyle(fontSize: 20)),
                Text('Silahkan Ke Tab "HOME"', 
                style: TextStyle(fontSize: 20))]),
              
              Stack(
              children: <Widget>[
              ListView(
              children: <Widget>[
              
              Container(
              color: Colors.orange[800],
              child: Container(
              decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(20),
                      topRight: Radius.circular(20))),
              height: 70,
              padding: EdgeInsets.only(left: 15),

                child: Row(
                  children: <Widget>[
                    Container(
                      height: 40,
                      decoration: BoxDecoration(
                      color: Colors.grey[200],
                      borderRadius: BorderRadius.all(
                        Radius.circular(50))),

                    child: Row(
                      children: <Widget> [
                        InkWell(
                        onTap: () {},
                        child: Container(
                              padding: EdgeInsets.only(left: 10),
                              child:Icon(Icons.search))),
                        Container(
                              padding: EdgeInsets.only(left: 10, right: 90), 
                              child: Text('Order the best nasgor in town...', 
                              style: TextStyle(color: Colors.grey, fontSize: 14))),
                        ]
                      )
                    ),
                    
                    InkWell(
                    onTap: () {},
                    child: (Container(
                      margin: EdgeInsets.only (left:10),
                      decoration: BoxDecoration(
                      color: Colors.green,
                      borderRadius: BorderRadius.all(
                      Radius.circular(50))),
                      child: Container(
                        margin: EdgeInsets.all(10),
                        child:Image.asset('images/account-non.png', 
                        width: 25, height: 25)),
                        )
                      )
                    ),
                  ],
                ),
              ),
            ),

            Container(
              height: 100,
              margin: EdgeInsets.only(left: 10, right: 10),
              decoration: BoxDecoration(
                  color: Colors.blue[700],
                  borderRadius: BorderRadius.all(
                      Radius.circular(12))),
              child: Container(
                padding: EdgeInsets.only(top: 15),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: <Widget>[
                    InkWell(
                    onTap: () {},
                    child: Saldo(
                      images: 'images/gopaycolor.png',
                      saldo: 'Rp18.420',
                      history: 'Tap for History',
                    )),
                    InkWell(
                    onTap: () {},
                    child: HeaderItem(
                      images: 'images/pay.png',
                      title: 'Pay',
                    )),
                    InkWell(
                    onTap: () {},
                    child: HeaderItem(
                      images: 'images/topup.png',
                      title: 'Top Up',
                    )),
                    InkWell(
                    onTap: () {},
                    child:HeaderItem(
                      images: 'images/more.png',
                      title: 'Explore',
                    )),
                  ],
                ),
              ),
            ),
          
          Container(
            padding: EdgeInsets.only(top: 20),
            margin: EdgeInsets.only(left: 10),
            child: Text( "Service you haven't tried",
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          ),
          
          Container(
            padding: EdgeInsets.only(top: 15, right: 5,left: 5),
          child: Row(
            children: <Widget> [
              InkWell(
              onTap: () {},
                child: Image.asset('images/freetoadjust.jpg', 
                width: 200, height: 300)),
              InkWell(
              onTap: () {},
                child:Image.asset('images/enjoyalot.jpg', 
                width: 200, height: 300)),
            ],
           )
          ),
          
          Container(
            padding: EdgeInsets.only(top: 20),
            margin: EdgeInsets.only(left: 10),
            child: Text( 'Top picks for you',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          ),

          Container(
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              InkWell(
                    onTap: () {},
                    child: (Container(
                      decoration: BoxDecoration(
                      color: Colors.green[800],
                      borderRadius: BorderRadius.all(
                      Radius.circular(50))),
                      child: Container(
                        padding: EdgeInsets.only(top:10, bottom: 10, left: 15, right: 15),
                        child:Text('All', 
                        style: TextStyle(color: Colors.white))),
                        )
                      )
                    ),
              Toppick(text: 'COVID-19'),
              Toppick(text: 'Entertainment'),
              Toppick(text: 'Food'),             
              Toppick(text: 'J3K'),]
            )),
          
          Container(
            padding: EdgeInsets.only(left:12, bottom: 10),
            alignment: Alignment.centerLeft,
            child:Image.asset('images/paylater.png', 
            scale: 1.5)),
          
          Container(
            margin: EdgeInsets.only(left: 10),
            child: Text( 'EXTRA with PayLater',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          ),
          
          Container(
            margin: EdgeInsets.only(left: 10, top: 5),
            child: Text( 'Get 50% cashback plus EXTRA 50k! Go use your Paylater now & enjoy its benefits to buy your need...',
            style: TextStyle(fontSize: 17)),
          ),

          InkWell(
          onTap: () {},
          child: (
          Container(
            padding: EdgeInsets.all(10),
            alignment: Alignment.centerLeft,
            child:Image.asset('images/paylater.jpg', 
            width:500, height: 350))),
            ),      
        ],
        ),

            Positioned(
              bottom: 20,
            child: Container(
              height: 80,
              width: 390,
              margin: EdgeInsets.only(left: 10, right: 10),
              decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.all(
                      Radius.circular(50)),
              boxShadow: [
                  BoxShadow(
                  color: Colors.grey.withOpacity(0.5),
                  spreadRadius: 5,
                  blurRadius: 7,
                  offset: Offset(0, 3),),],),
              child: Container(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: <Widget>[
                    InkWell(
                    onTap: () {},
                    child: Menu(
                      images: 'images/gocar.png',
                      title: 'GoCar',
                    )),

                    InkWell(
                    onTap: (){
                      Navigator.push(context, 
                      MaterialPageRoute(builder: (context) => Page2()),
                    );},
                    child: Column(
                    children: <Widget>[
                    Container(
                    padding: EdgeInsets.only(top: 10),
                    child:Image.asset(
                    'images/gofood.png',
                    width: 40,
                    height: 40
                    )),
                    SizedBox(
                    height: 5,
                    ),
                    Text(
                    'GoFood',
                    style: TextStyle(color: Colors.black),
                    )
                    ],
                    )),
                    
                    InkWell(
                    onTap: () {},
                    child: Menu(
                      images: 'images/gosend.png',
                      title: 'GoSend',
                    )),

                    InkWell(
                    onTap: () {},
                    child: Menu(
                      images: 'images/gomedi.png',
                      title: 'GoMed',
                    )),
                  ],
                ),
              ),
            ),
        ) 
      ],
      ),

              Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                Text('Coming Soon', 
                style: TextStyle(fontSize: 20)),
                Text('Silahkan Ke Tab "HOME"', 
                style: TextStyle(fontSize: 20))]),
            ],
          ),
        ),
      ),
    );
  }
}

class HeaderItem extends StatelessWidget {
  const HeaderItem({Key key, this.images, this.title, this.textcolor})
      : super(key: key);
  final String images;
  final String title;
  final Color textcolor;
  @override
  Widget build(BuildContext context) {
    return Container(
      width: 80,
      child: Column(
        children: <Widget>[
          Container(
            padding: EdgeInsets.only(top: 10),
            child:Image.asset(
            images,
            scale: 3,
          )),
          SizedBox(
            height: 7,
          ),
          Text(
            title,
            style: TextStyle(color: textcolor ?? Colors.white),
          )
        ],
      ),
    );
  }
}

class Saldo extends StatelessWidget {
  const Saldo({Key key, this.images, this.saldo, this.history, this.textcolor})
      : super(key: key);
  final String images;
  final String saldo;
  final String history;
  final Color textcolor;
  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(left: 10, bottom: 20),
      decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.all(
                      Radius.circular(12))),
      width: 120,
      height: 70,
      child: Column(
        children: <Widget>[
          Container(
            padding: EdgeInsets.only(left:10, top: 10),
            alignment: Alignment.centerLeft,
            child:Image.asset(
            images,
            scale: 3,
          )),
          SizedBox(
            height: 3,
          ),
          Container(
            padding: EdgeInsets.only(left:10),
            alignment: Alignment.centerLeft,
            child:Text(
            saldo,
            style: TextStyle(color: textcolor ?? 
                    Colors.black, fontWeight: FontWeight.bold, fontSize: 16),
          )),
          SizedBox(
            height: 3,
          ),
          Container(
            padding: EdgeInsets.only(left:10),
            alignment: Alignment.centerLeft,
            child:Text(
            history,
            style: TextStyle(color: textcolor ?? 
                    Colors.green, fontWeight: FontWeight.bold, fontSize: 11),
          ))
        ],
      ),
    );
  }
}

class Toppick extends StatelessWidget {
  const Toppick({Key key, this.text, this.textcolor})
      : super(key: key);
  final String text;
  final Color textcolor;
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.only(top: 20, bottom: 25),
      child: 
      InkWell(
       onTap: () {},
        child: (Container(
      decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.all(
            Radius.circular(50)),
      border: Border.all(width: 1.0, color: Colors.grey)
          ),
            padding: EdgeInsets.only(top:10, bottom: 10, left: 15, right: 15),
            child:Text(
            text,
            style: TextStyle(color: textcolor ?? Colors.grey)),
          )
        )
      )
    );
  }
}

class Menu extends StatelessWidget {
  const Menu({Key key, this.images, this.title, this.textcolor})
      : super(key: key);
  final String images;
  final String title;
  final Color textcolor;
  @override
  Widget build(BuildContext context) {
    return Container(
      child: Column(
        children: <Widget>[
          Container(
            padding: EdgeInsets.only(top: 10),
            child:Image.asset(
            images,
            width: 40,
            height: 40
          )),
          SizedBox(
            height: 5,
          ),
          Text(
            title,
            style: TextStyle(color: textcolor ?? Colors.black),
          )
        ],
      ),
    );
  }
}
