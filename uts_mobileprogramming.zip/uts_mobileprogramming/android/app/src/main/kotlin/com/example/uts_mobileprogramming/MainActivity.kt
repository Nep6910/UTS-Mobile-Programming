package com.example.uts_mobileprogramming

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
